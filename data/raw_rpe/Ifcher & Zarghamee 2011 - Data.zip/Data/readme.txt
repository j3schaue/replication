{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww13500\viewh13200\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs36 \cf0 Replication Materials for Ifcher and Zarghamee (2011)\
\
1. Data file\
- all.dta: Merged data including (i) answers to time discounting questions, (ii) self-reported happiness, (iii) demographic information, and (iv) PANAS ratings. \
\
2. Scripts\
- replication.do: Run regressions (based mostly on the original script) and run additional regressions as well. }